﻿Option Explicit On

Public Class Form1
    Dim myAgentElement As New AgentElement
    Dim Ua, Ca, Hm, Cm, GHEqArea, StepSize, HtCapacity, DeadBandEachSide As Double
    Dim NStepsPerHour As Int16
    Dim qAirFirstStep, qOnMassFirstStep, TBegin0, TBegin1, TOutBegin1 As Double
    Dim AuxLast As Integer
    Dim HourNo As Integer
    Dim TOutForHour, TSetHtForHour, QIntForHour, QmassForHour, GH_SolarForHour, TLoForHour, THiForHour As Double
    Dim TOutTick1, qAirStep01, qSolar01, qOnMassStep01 As Double
    Dim Aux01 As Integer
    Dim TTick1, qMassTick1 As Double
    Dim Aux01Prev As Integer
    Dim StateChanged As Integer, StepFraction, TTickZero As Double
    Dim TimeMark, CumOnTime, TimeMarkPrev As Double, AuxBeforeChange As Integer

    Sub SetInit()
        Ua = 475.0
        Ca = 360.0
        Hm = 10910.0
        Cm = 5000.0
        GHEqArea = 25
        NStepsPerHour = 240
        StepSize = 1.0 / NStepsPerHour
        HtCapacity = 40000
        DeadBandEachSide = 1.0
        With myAgentElement
            .Ua = Ua
            .Ca = Ca
            .Hm = Hm
            .Cm = Cm
            .GHEqArea = GHEqArea
            .HtCapacity = HtCapacity
            .StepSize = StepSize
            .TCIntPol = 0.5
        End With
        TBegin0 = 60.0
        TBegin1 = 59.9
        TOutBegin1 = 37.3
        qAirFirstStep = 1000
        qOnMassFirstStep = 0.0
        AuxLast = 0
        myAgentElement.InitializeqT(qAirFirstStep, qOnMassFirstStep, TBegin0, TBegin1, AuxLast, TOutBegin1)
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SetInit()
        Dim ConnStr As String
        Dim TimeMarkHr, TimeMarkMin, TimeMarkSec As Integer
        '*****Change the path suitably or modify the settings******
        ConnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Documents and Settings\d3x998\My Documents\SmartGrid1\ETPv3\AgentETP\BuildingSim_GridLabD.accdb;"
        Dim OLEDBConnection1 As New OleDb.OleDbConnection(connectionString:=ConnStr)
        Dim cmd As New OleDb.OleDbCommand
        Dim reader As OleDb.OleDbDataReader
        cmd.CommandText = "SELECT HourNo, ToutF, TSetHt, TSetC, QInt, GH_Solar, Qmass FROM HourlyData"
        cmd.CommandType = CommandType.Text
        cmd.Connection = OLEDBConnection1
        OLEDBConnection1.Open()
        Dim dum As String
        reader = cmd.ExecuteReader()
        ' Data is accessible through the DataReader object here.

        Dim cmd2 As New OleDb.OleDbCommand
        Dim recordsAffected As Int32
        Dim IsFirst As Boolean
        IsFirst = True
        cmd2.CommandType = CommandType.Text
        cmd2.Connection = OLEDBConnection1
        dum = "Delete * FROM TandQ"
        cmd2.CommandText = dum
        recordsAffected = cmd2.ExecuteNonQuery()
        While (reader.Read())
            HourNo = reader("HourNo")
            TOutForHour = reader("ToutF")
            TSetHtForHour = reader("TSetHt")
            QIntForHour = reader("QInt")
            QmassForHour = reader("Qmass")
            GH_SolarForHour = reader("GH_Solar")
            TLoForHour = TSetHtForHour - DeadBandEachSide
            THiForHour = TSetHtForHour + DeadBandEachSide
            For SubHourNo = 1 To NStepsPerHour
                TOutTick1 = TOutForHour
                qAirStep01 = QIntForHour
                qOnMassStep01 = QmassForHour
                qSolar01 = GHEqArea * GH_SolarForHour
                Aux01Prev = Aux01
                myAgentElement.ComputeNewTQ(qAirStep01, qSolar01, qOnMassStep01, TOutTick1, TLoForHour, THiForHour, TTickZero, TTick1, qMassTick1, Aux01, _
                                            StateChanged, StepFraction)
                dum = "INSERT INTO TandQ (HourNo, SubHourNo, TInBegin,TInEnd,TOut, AuxOn,StateChanged, StepFraction,TimeMark,CumOnTime) "
                dum = dum & "Values (" & HourNo & "," & SubHourNo & "," & TTickZero & "," & TTick1 & "," & TOutTick1 & "," & Aux01 & ","
                'dum = dum & "Values (" & HourNo & "," & SubHourNo & "," & TTickZero & "," & TTick1 & "," & (SubHourNo - 1 + StepFraction) / NStepsPerHour * 60 & "," & Aux01 & ","
                dum = dum & StateChanged & "," & StepFraction & "," & TimeMark & "," & CumOnTime & ")"
                If IsFirst Then
                    CumOnTime = 0.0
                    TimeMarkPrev = HourNo + (SubHourNo - 1) / NStepsPerHour
                    IsFirst = False
                End If
                If StateChanged = 1 Then
                    TimeMark = HourNo + (SubHourNo - 1 + StepFraction) / NStepsPerHour
                    TimeMarkHr = Int(TimeMark - 1105)
                    TimeMarkMin = Int((TimeMark - 1105 - TimeMarkHr) * 60)
                    TimeMarkSec = Int(((TimeMark - 1105 - TimeMarkHr) * 60 - TimeMarkMin) * 60)
                    CumOnTime = CumOnTime + 60.0 * (TimeMark - TimeMarkPrev) * AuxBeforeChange
                    dum = "INSERT INTO TandQ (HourNo, SubHourNo, TInBegin,TInEnd,TOut, AuxOn,StateChanged, StepFraction,TimeMark,CumOnTime,TimemarkHr,TimeMarkMin,TimeMarkSec) "
                    dum = dum & "Values (" & HourNo & "," & SubHourNo & "," & TTickZero & "," & TTick1 & "," & TOutTick1 & "," & Aux01 & ","
                    dum = dum & StateChanged & "," & StepFraction & "," & TimeMark & "," & CumOnTime & "," & TimeMarkHr & "," & TimeMarkMin & "," & TimeMarkSec & ")"
                    cmd2.CommandText = dum
                    recordsAffected = cmd2.ExecuteNonQuery()
                    TimeMarkPrev = TimeMark
                    AuxBeforeChange = Aux01
                End If
            Next
        End While
        OLEDBConnection1.Close()
    End Sub
End Class
