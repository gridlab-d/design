﻿Option Explicit On
Imports System.Math

Public Class AgentElement
    Public Ca, Ua, Cm, Hm, GHEqArea, StepSize, HtCapacity, TCIntPol As Double  'Parameters
    'Public Delta, qAirStep01, qOnMassStep01, TOutTick1  'Inputs
    'Public TTick1, qMassTick1 As Double  'Outputs
    Public xMid, qMid, xRem As Double
    Private TTick0, qMassTick0 As Double, AuxMinus10 As Integer  'Stored for the next step (Minus1,0 refers to last step)
    Private Rat, AlphaM, AA, BB, AAP, BBP, RInt, c1, c2, c3, c4, c5, AAb, TempRise As Double

    Public TTick01, qTick01, TMassTick1 As Double  'extra outputs, quick and dirty

    Public Sub InitializeqT(ByVal qAirFirstStep As Double, _
        ByVal qOnMassFirstStep As Double, ByVal TBeginStep As Double, ByVal TEndStep As Double, _
        ByVal AuxLast As Integer, ByVal TOutEndStep As Double)
        Dim dum, qMassBeginStep, CTemp As Double
        Rat = StepSize * Hm / Cm
        AlphaM = Math.Exp(-Rat)
        AA = (1 - AlphaM)
        BB = 1 - AA / Rat
        AAb = 1 - Math.Exp(-Rat * TCIntPol)
        RInt = 1 / AAb - 1 / (Rat * TCIntPol)
        If Not Double.IsNaN(RInt) Then
            BBP = (1.0 - TCIntPol * AA / AAb) / (1.0 - TCIntPol)
            AAP = Rat * (1.0 - BBP)
        Else
            AAP = AA
            BBP = BB
            RInt = 0.5
        End If
        CTemp = Ca + Ua * RInt * StepSize + BBP * Cm
        c1 = StepSize / CTemp
        c2 = Ua * StepSize / CTemp
        c3 = BB * StepSize / CTemp
        c4 = AA * Cm / Hm / CTemp
        c5 = AAP * Hm / Rat
        TempRise = HtCapacity * StepSize / CTemp
        dum = qAirFirstStep - Ua * (TBeginStep - TOutEndStep) + BB * qOnMassFirstStep
        dum = CTemp * (TEndStep - TBeginStep) / StepSize - dum
        qMassBeginStep = dum * Rat / AA
        qMassTick0 = qMassBeginStep + AA * (-qMassBeginStep + qOnMassFirstStep) - AAP * Hm * (TEndStep - TBeginStep) / Rat
        TTick0 = TEndStep
        AuxMinus10 = AuxLast
    End Sub

    Public Sub ComputeNewTQ(ByVal qAirStep01 As Double, ByVal qSolar01 As Double, _
        ByVal qOnMassStep01 As Double, ByVal TOutTick1 As Double, _
        ByVal TLo As Double, ByVal THi As Double, ByRef TTickZero As Double, ByRef TTick1 As Double, ByRef qMassTick1 As Double, _
        ByRef Aux01 As Integer, ByRef StateChanged As Integer, ByRef StepFraction As Double)
        Dim dum, TFullStepFromMid As Double
        'Test temperature at the end of time step with aux heat off
        TTick1 = TTick0 + c1 * (qAirStep01 + qSolar01) - c2 * (TTick0 - TOutTick1) + c3 * qOnMassStep01 + c4 * qMassTick0
        Aux01 = 0
        qMassTick1 = qMassTick0 + AA * (-qMassTick0 + qOnMassStep01) - c5 * (TTick1 - TTick0)
        StateChanged = 0
        StepFraction = 0
        If (AuxMinus10 = 0 And TTick0 >= TLo) Or TTick0 > THi Then
            'aux was off coming into the step, or THi was reduced (night setback) below TTick0
            'So this step starts with aux off. Question is can it be off for the entire step
            'If it is to be turned on in the middle of the step, we will let it remain
            'on rest of the step. Be sure, the steps are small enough that more
            'than one state change is not needed within a step
            If TTick1 >= TLo Then
                Aux01 = 0
                If AuxMinus10 = 1 Then
                    StateChanged = 1
                    StepFraction = 0
                End If
            Else
                'Turn aux on sometime in the middle of the step, but process full step
                'For the first part, temp at the end of step is TTick1
                dum = (1 - Math.Exp(-Rat * TCIntPol)) * (TLo - TTick0) / (TTick1 - TTick0)
                xMid = -Math.Log(1 - dum) / TCIntPol
                StepFraction = xMid / Rat
                StateChanged = 1
                dum = (TTick1 - TTick0) * (1 - Math.Exp(-xMid)) / AAb
                dum = TCIntPol / (1 - TCIntPol) * (dum - TLo + TTick0)
                qMid = qMassTick0 + (1 - Math.Exp(-xMid)) * (-qMassTick0 + qOnMassStep01) - Hm * dum
                'For the second part, aux is off, temp at the end of full step is:
                TFullStepFromMid = TempRise + TLo + c1 * (qAirStep01 + qSolar01) - c2 * (TLo - TOutTick1) + c3 * qOnMassStep01 + c4 * qMid
                xRem = Rat - xMid
                TTick1 = TLo + (TFullStepFromMid - TLo) * (1 - Math.Exp(-TCIntPol * xRem)) / AAb
                qMassTick1 = qMid + (1 - Math.Exp(-xRem)) * (-qMid + qOnMassStep01) - _
                            Hm * (TFullStepFromMid - TLo) * TCIntPol / (1 - TCIntPol) / AAb * (Math.Exp(-TCIntPol * xRem) - Math.Exp(-xRem))
                Aux01 = 1
            End If
        ElseIf (AuxMinus10 = 1 And TTick0 < THi) Or TTick0 < TLo Then
            'aux was on coming into the step, or TLo was increased (set forward) above TTick0
            If TTick1 + TempRise <= THi Then
                Aux01 = 1
                TTick1 = TTick1 + TempRise
                qMassTick1 = qMassTick1 - c5 * TempRise
                If AuxMinus10 = 0 Then
                    StateChanged = 1
                    StepFraction = 0
                End If
            Else
                'Turn aux off sometime in the middle of the step, but process full step
                'For the first part, temp at the end of full step is TTick1 + TempRise
                dum = (1 - Math.Exp(-Rat * TCIntPol)) * (THi - TTick0) / (TTick1 + TempRise - TTick0)
                xMid = -Math.Log(1 - dum) / TCIntPol
                StepFraction = xMid / Rat
                StateChanged = 1
                dum = (TTick1 + TempRise - TTick0) * (1 - Math.Exp(-xMid)) / AAb
                dum = TCIntPol / (1 - TCIntPol) * (dum - THi + TTick0)
                qMid = qMassTick0 + (1 - Math.Exp(-xMid)) * (-qMassTick0 + qOnMassStep01) - Hm * dum
                'For the second part, aux is off, temp at the end of full step is:
                TFullStepFromMid = THi + c1 * (qAirStep01 + qSolar01) - c2 * (THi - TOutTick1) + c3 * qOnMassStep01 + c4 * qMid
                xRem = Rat - xMid
                TTick1 = THi + (TFullStepFromMid - THi) * (1 - Math.Exp(-TCIntPol * xRem)) / AAb
                qMassTick1 = qMid + (1 - Math.Exp(-xRem)) * (-qMid + qOnMassStep01) - _
                            Hm * (TFullStepFromMid - THi) * TCIntPol / (1 - TCIntPol) / AAb * (Math.Exp(-TCIntPol * xRem) - Math.Exp(-xRem))
                Aux01 = 0
            End If
        Else
            MsgBox("Unhandled case")
        End If
        'Update
        qMassTick0 = qMassTick1
        TTickZero = TTick0
        TTick0 = TTick1
        AuxMinus10 = Aux01
    End Sub

    'Public Sub ComputeNewTQOld(ByVal qAirStep01 As Double, ByVal qSolar01 As Double, _
    '   ByVal qOnMassStep01 As Double, ByVal TOutTick1 As Double, ByVal AuxLast As Integer, _
    '   ByVal TLo As Double, ByVal THi As Double, ByRef TTick1 As Double, ByRef qMassTick1 As Double, ByRef Aux01 As Integer)
    '    'Test temperature at the end of time step with aux heat off
    '    TTick1 = TTick0 + c1 * (qAirStep01 + qSolar01) - c2 * (TTick0 - TOutTick1) + c3 * qOnMassStep01 + c4 * qMassTick0
    '    Aux01 = 0
    '    qMassTick1 = qMassTick0 + AA * (-qMassTick0 + qOnMassStep01) - c5 * (TTick1 - TTick0)
    '    'This version: check at the beginning of the step and decide on/off for the whole step.
    '    'This resulted in T>THi on the way up before off event and T<TLo on the way down before on event
    '    If (TTick0 > TLo And TTick0 < THi And AuxMinus10 = 1) Or TTick0 < TLo Then
    '        Aux01 = 1
    '        TTick1 = TTick1 + TempRise
    '        qMassTick1 = qMassTick1 - c5 * TempRise
    '    End If
    '    'Update
    '    qMassTick0 = qMassTick1
    '    TTick0 = TTick1
    '    AuxMinus10 = Aux01
    'End Sub

    'Public Sub ComputeNewTQRightPartial(ByVal qAirInStep As Double, ByVal qSolarInStep As Double, _
    ' ByVal qOnMassInStep As Double, ByVal TOutInStep As Double, ByVal AuxOffOn As Integer, _
    ' ByVal TBeginMid As Double, ByVal qBeginMid As Double, ByVal xMid As Double, ByRef TStepEnd As Double, ByRef qStepEnd As Double)
    '    Dim TFullStepFromMid, xRem As Double
    '    TFullStepFromMid = TBeginMid + AuxOffOn * TempRise + c1 * (qAirInStep + qSolarInStep) - c2 * (TBeginMid - TOutInStep) + c3 * qOnMassInStep + c4 * qBeginMid
    '    xRem = Rat - xMid
    '    TStepEnd = TBeginMid + (TFullStepFromMid - TBeginMid) * (1 - Math.Exp(-TCIntPol * xRem)) / AAb
    '    qStepEnd = Math.Exp(-xRem) + (1 - Math.Exp(-xRem)) * (qAirInStep + qSolarInStep) - _
    '                Hm * (TFullStepFromMid - TBeginMid) * TCIntPol / (1 - TCIntPol) / AAb * (Math.Exp(-TCIntPol * xRem) - Math.Exp(-xRem))
    'End Sub

    'Public Sub ComputeNewQLeftPartial(ByVal qAirInStep As Double, ByVal qSolarInStep As Double, _
    '    ByVal qOnMassInStep As Double, ByVal TOutInStep As Double, ByVal AuxOffOn As Integer, _
    '    ByVal TStepBegin As Double, ByVal qStepBegin As Double, ByVal TEndMid As Double, ByVal xMid As Double, ByRef qEndMid As Double)
    '    'Note that only new Q is computed, new T is already known to be the limiting Temp. The 
    '    Dim TFullStepFromBegin
    '    TFullStepFromBegin = TStepBegin + AuxOffOn * TempRise + c1 * (qAirInStep + qSolarInStep) - c2 * (TStepBegin - TOutInStep) + c3 * qOnMassInStep + c4 * qStepBegin
    '    qEndMid = Math.Exp(-xMid) * q + (1 - Math.Exp(-xMid)) * (qAirInStep + qSolarInStep) - _
    '                Hm * (TFullStepFromBegin - TStepBegin) * TCIntPol / (1 - TCIntPol) / AAb * (Math.Exp(-TCIntPol * xMid) - Math.Exp(-xMid))
    'End Sub
End Class

